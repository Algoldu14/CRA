﻿
%------------------------------- ANALIZADOR -----------------------------------------------------
% Autor:
% Fecha: 14/03/2019

:-consult('./DiccionarioEs.pl').
:-consult('./DiccionarioEn.pl').
:-consult('./GramaticaEn.pl').
:-consult('./GramaticaEs.pl').
:-consult('./draw.pl').
:-consult('./Tests.pl').












